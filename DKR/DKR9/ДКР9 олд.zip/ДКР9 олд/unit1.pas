unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus, ExtCtrls,
  Grids, StdCtrls, LCLType;

type
  TContract = record
    Num: string[20];        // Номер договора
    CDate: string[15];      // Дата
    ClientName: string[100];// ФИО клиента
    Amount: Double;         // Сумма
    Period: string[30];     // Срок действия
    Status: string[20];     // Статус
  end;

  { TForm1 }

  TForm1 = class(TForm)
      ComboStatus: TComboBox;
      EditNum: TEdit;
      EditDate: TEdit;
      EditName: TEdit;
      EditAmount: TEdit;
      EditPeriod: TEdit;

      // === ВОТ ЭТИ СТРОКИ НАДО ДОПИСАТЬ ===
      Label1: TLabel;
      Label2: TLabel;
      Label3: TLabel;
      Label4: TLabel;
      Label5: TLabel;
      Label6: TLabel;
      // ===================================

    MainMenu1: TMainMenu;
    FileMenu: TMenuItem;
    MenuItemNew: TMenuItem;
    MenuItemOpen: TMenuItem;
    MenuItemSave: TMenuItem;
    MenuItemSaveAs: TMenuItem;
    MenuItemClose: TMenuItem;
    MenuItemExit: TMenuItem;
    RecordMenu: TMenuItem;
    MenuItemAdd: TMenuItem;
    MenuItemEdit: TMenuItem;
    MenuItemDelete: TMenuItem;
    SortMenu: TMenuItem;
    MenuItemSortAsc: TMenuItem;
    MenuItemSortDesc: TMenuItem;
    ActionMenu: TMenuItem;
    MenuItemSearch: TMenuItem;
    MenuItemClear: TMenuItem;
    OpenDialog1: TOpenDialog;
    Panel1: TPanel;
    SaveDialog1: TSaveDialog;
    StringGrid1: TStringGrid;
    procedure EditAmountKeyPress(Sender: TObject; var Key: char);
    procedure EditDateKeyPress(Sender: TObject; var Key: char);
    procedure EditNumKeyPress(Sender: TObject; var Key: char);
    procedure FormCreate(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure MenuItemNewClick(Sender: TObject);
    procedure MenuItemOpenClick(Sender: TObject);
    procedure MenuItemSaveClick(Sender: TObject);
    procedure MenuItemSaveAsClick(Sender: TObject);
    procedure MenuItemCloseClick(Sender: TObject);
    procedure MenuItemExitClick(Sender: TObject);
    procedure MenuItemAddClick(Sender: TObject);
    procedure MenuItemEditClick(Sender: TObject);
    procedure MenuItemDeleteClick(Sender: TObject);
    procedure MenuItemSortAscClick(Sender: TObject);
    procedure MenuItemSortDescClick(Sender: TObject);
    procedure MenuItemSearchClick(Sender: TObject);
    procedure MenuItemClearClick(Sender: TObject);
    procedure StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean);
  private
    CurrentFile: string;   // Путь к текущему открытому файлу
    IsFileOpen: Boolean;   // Флаг: открыт ли файл вообще
    IsModified: Boolean;   // Флаг: есть ли несохраненные изменения
    procedure SaveToFile(FileName: string);
    procedure LoadFromFile(FileName: string);
    procedure ClearGrid;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.EditAmountKeyPress(Sender: TObject; var Key: Char);
begin
  // Разрешаем только цифры, Backspace (#8), запятую и точку
  if not (Key in ['0'..'9', #8, ',', '.']) then
    Key := #0; // Игнорируем нажатие букв или спецсимволов

  // Умная замена: подстраиваем точку или запятую под стандарты твоей Windows/Linux,
  // чтобы программа не вылетала из-за неверного знака дроби
  if (Key = '.') or (Key = ',') then
    Key := DefaultFormatSettings.DecimalSeparator;
end;

procedure TForm1.EditDateKeyPress(Sender: TObject; var Key: Char);
begin
  // Разрешаем только цифры, точку и Backspace
  if not (Key in ['0'..'9', #8, '.']) then
    Key := #0;
end;

procedure TForm1.EditNumKeyPress(Sender: TObject; var Key: char);
begin

end;

// 1. Инициализация формы при старте программы
procedure TForm1.FormCreate(Sender: TObject);
begin
  // Настройка колонок таблицы
  StringGrid1.ColCount := 6;
  StringGrid1.RowCount := 1; // Только шапка
  StringGrid1.FixedRows := 1;

  StringGrid1.Cells[0, 0] := 'Номер договора';
  StringGrid1.Cells[1, 0] := 'Дата';
  StringGrid1.Cells[2, 0] := 'ФИО клиента';
  StringGrid1.Cells[3, 0] := 'Сумма';
  StringGrid1.Cells[4, 0] := 'Срок действия';
  StringGrid1.Cells[5, 0] := 'Статус';

  IsFileOpen := False;
  IsModified := False;
  CurrentFile := '';
end;


// Очистка таблицы
procedure TForm1.ClearGrid;
begin
  StringGrid1.RowCount := 1;
  IsModified := False;
end;

// Вспомогательный метод загрузки данных из типизированного файла
procedure TForm1.LoadFromFile(FileName: string);
var
  F: file of TContract;
  Rec: TContract;
  RowIndex: Integer;
begin
  AssignFile(F, FileName);
  try
    Reset(F);

    // Проверка на корректность формата (кратность размеру записи)
    if (FileSize(F) > 0) and ((FileSize(F) * SizeOf(TContract)) mod SizeOf(TContract) <> 0) then
    begin
      ShowMessage('Ошибка: Файл имеет некорректный формат или поврежден.');
      CloseFile(F);
      Exit;
    end;

    ClearGrid;
    RowIndex := 1;

    while not EOF(F) do
    begin
      Read(F, Rec);
      StringGrid1.RowCount := StringGrid1.RowCount + 1;
      StringGrid1.Cells[0, RowIndex] := Rec.Num;
      StringGrid1.Cells[1, RowIndex] := Rec.CDate;
      StringGrid1.Cells[2, RowIndex] := Rec.ClientName;
      StringGrid1.Cells[3, RowIndex] := FloatToStr(Rec.Amount);
      StringGrid1.Cells[4, RowIndex] := Rec.Period;
      StringGrid1.Cells[5, RowIndex] := Rec.Status;
      Inc(RowIndex);
    end;

    CurrentFile := FileName;
    IsFileOpen := True;
    IsModified := False;
  except
    on E: EInOutError do
      ShowMessage('Ошибка ввода-вывода при чтении файла. Возможно, он занят другим процессом.');
  end;

  // Закрываем файл гарантированно через дескриптор, если он был назначен
  {$I-} CloseFile(F); {$I+}
  IOResult; // Сбрасываем ошибку I/O, если файла не было
end;

// Вспомогательный метод сохранения данных в типизированный файл
procedure TForm1.SaveToFile(FileName: string);
var
  F: file of TContract;
  Rec: TContract;
  i: Integer;
begin
  AssignFile(F, FileName);
  try
    Rewrite(F);
    for i := 1 to StringGrid1.RowCount - 1 do
    begin
      Rec.Num := StringGrid1.Cells[0, i];
      Rec.CDate := StringGrid1.Cells[1, i];
      Rec.ClientName := StringGrid1.Cells[2, i];
      Rec.Amount := StrToFloatDef(StringGrid1.Cells[3, i], 0);
      Rec.Period := StringGrid1.Cells[4, i];
      Rec.Status := StringGrid1.Cells[5, i];
      Write(F, Rec);
    end;
    CurrentFile := FileName;
    IsFileOpen := True;
    IsModified := False;
    ShowMessage('Данные успешно сохранены.');
  except
    on E: EInOutError do
      ShowMessage('Ошибка сохранения: Недостаточно места на диске или нет прав доступа.');
  end;
  {$I-} CloseFile(F); {$I+}
  IOResult;
end;

// Файл -> Создать / Новый файл
procedure TForm1.MenuItemNewClick(Sender: TObject);
begin
  if IsModified then
    if MessageDlg('Сохранить изменения в текущем файле?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      MenuItemSaveClick(Sender);

  ClearGrid;
  CurrentFile := '';
  IsFileOpen := True;
  ShowMessage('Создан новый пустой документ.');
end;

// Файл -> Открыть файл
procedure TForm1.MenuItemOpenClick(Sender: TObject);
begin
  if IsModified then
    if MessageDlg('Сохранить изменения перед открытием нового файла?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      MenuItemSaveClick(Sender);

  if OpenDialog1.Execute then
    LoadFromFile(OpenDialog1.FileName);
end;

// Файл -> Сохранить
procedure TForm1.MenuItemSaveClick(Sender: TObject);
begin
  if CurrentFile <> '' then
    SaveToFile(CurrentFile)
  else
    MenuItemSaveAsClick(Sender);
end;

// Файл -> Сохранить как
procedure TForm1.MenuItemSaveAsClick(Sender: TObject);
begin
  if SaveDialog1.Execute then
    SaveToFile(SaveDialog1.FileName);
end;

// Файл -> Закрыть файл
procedure TForm1.MenuItemCloseClick(Sender: TObject);
begin
  if IsModified then
    if MessageDlg('Файл изменен. Сохранить перед закрытием?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      MenuItemSaveClick(Sender);

  ClearGrid;
  CurrentFile := '';
  IsFileOpen := False;
end;

// Перехват закрытия программы (Проверка на несохраненные изменения)
procedure TForm1.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if IsModified then
  begin
    case MessageDlg('Есть несохраненные изменения. Сохранить перед выходом?', mtConfirmation, [mbYes, mbNo, mbCancel], 0) of
      mrYes:
        begin
          MenuItemSaveClick(nil);
          CanClose := True;
        end;
      mrNo: CanClose := True;
      mrCancel: CanClose := False;
    end;
  end
  else
    CanClose := True;
end;

// Файл -> Выход
procedure TForm1.MenuItemExitClick(Sender: TObject);
begin
  Close;
end;

// Запись -> Добавить запись (Исправленная версия)
procedure TForm1.MenuItemAddClick(Sender: TObject);
var
  NewRow: Integer;
  // Временные переменные для безопасного хранения ввода
  sNum, sDate, sName, sPeriod, sStatus: string;
  sAmount: Double;
begin
  // 1. Первым делом строго сохраняем всё, что ввёл пользователь
  sNum := EditNum.Text;
  sDate := EditDate.Text;
  sName := EditName.Text;
  sPeriod := EditPeriod.Text;
  sStatus := ComboStatus.Text;

  // Проверка пустых полей (теперь проверяем сохраненные переменные)
  if (Trim(sNum) = '') or (Trim(sName) = '') then
  begin
    ShowMessage('Ошибка: Поля "Номер договора" и "ФИО клиента" обязательны для заполнения!');
    Exit;
  end;

  // Проверка корректности ввода числа
  try
    sAmount := StrToFloat(EditAmount.Text);
  except
    on EConvertError do
    begin
      ShowMessage('Ошибка ввода: Поле "Сумма" должно содержать число (используйте запятую для дробей).');
      Exit;
    end;
  end;

  // 2. И только теперь, когда данные в безопасности, работаем с таблицей
  StringGrid1.RowCount := StringGrid1.RowCount + 1;
  NewRow := StringGrid1.RowCount - 1;

  // Заполняем таблицу из наших временных переменных
  StringGrid1.Cells[0, NewRow] := sNum;
  StringGrid1.Cells[1, NewRow] := sDate;
  StringGrid1.Cells[2, NewRow] := sName;
  StringGrid1.Cells[3, NewRow] := FloatToStr(sAmount);
  StringGrid1.Cells[4, NewRow] := sPeriod;
  StringGrid1.Cells[5, NewRow] := sStatus;

  IsModified := True;
  MenuItemClearClick(Sender); // Авто-очистка полей ввода после добавления
end;

// Запись -> Редактировать запись (Исправленная версия)
procedure TForm1.MenuItemEditClick(Sender: TObject);
var
  SelRow: Integer;
  sNum, sDate, sName, sPeriod, sStatus: string;
  sAmount: Double;
begin
  SelRow := StringGrid1.Row;
  if (SelRow < 1) or (SelRow >= StringGrid1.RowCount) then
  begin
    ShowMessage('Ошибка: Сначала выберите запись в таблице для редактирования.');
    Exit;
  end;

  // Точно так же сначала копируем данные в переменные
  sNum := EditNum.Text;
  sDate := EditDate.Text;
  sName := EditName.Text;
  sPeriod := EditPeriod.Text;
  sStatus := ComboStatus.Text;

  if (Trim(sNum) = '') or (Trim(sName) = '') then
  begin
    ShowMessage('Ошибка: Поля не могут быть пустыми.');
    Exit;
  end;

  try
    sAmount := StrToFloat(EditAmount.Text);
  except
    on EConvertError do
    begin
      ShowMessage('Ошибка ввода: Некорректный формат суммы.');
      Exit;
    end;
  end;

  // Записываем сохраненные переменные в таблицу
  StringGrid1.Cells[0, SelRow] := sNum;
  StringGrid1.Cells[1, SelRow] := sDate;
  StringGrid1.Cells[2, SelRow] := sName;
  StringGrid1.Cells[3, SelRow] := FloatToStr(sAmount);
  StringGrid1.Cells[4, SelRow] := sPeriod;
  StringGrid1.Cells[5, SelRow] := sStatus;

  IsModified := True;
end;

// Запись -> Удалить запись
procedure TForm1.MenuItemDeleteClick(Sender: TObject);
var
  SelRow, i, j: Integer;
begin
  SelRow := StringGrid1.Row;
  if (SelRow < 1) or (SelRow >= StringGrid1.RowCount) then
  begin
    ShowMessage('Ошибка: Выберите запись в таблице для удаления.');
    Exit;
  end;

  if MessageDlg('Вы уверены, что хотите удалить выбранную запись?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    // Сдвиг строк вверх
    for i := SelRow to StringGrid1.RowCount - 2 do
      for j := 0 to StringGrid1.ColCount - 1 do
        StringGrid1.Cells[j, i] := StringGrid1.Cells[j, i + 1];

    StringGrid1.RowCount := StringGrid1.RowCount - 1;
    IsModified := True;
    MenuItemClearClick(Sender);
  end;
end;

// Действия -> Очистить форму
procedure TForm1.MenuItemClearClick(Sender: TObject);
begin
  EditNum.Clear;
  EditDate.Clear;
  EditName.Clear;
  EditAmount.Clear;
  EditPeriod.Clear;
  ComboStatus.ItemIndex := -1;
end;

// Клик по строке таблицы автоматически переносит данные в поля ввода (для удобства редактирования)
procedure TForm1.StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean);
begin
  if (aRow >= 1) and (aRow < StringGrid1.RowCount) then
  begin
    EditNum.Text := StringGrid1.Cells[0, aRow];
    EditDate.Text := StringGrid1.Cells[1, aRow];
    EditName.Text := StringGrid1.Cells[2, aRow];
    EditAmount.Text := StringGrid1.Cells[3, aRow];
    EditPeriod.Text := StringGrid1.Cells[4, aRow];
    ComboStatus.Text := StringGrid1.Cells[5, aRow];
  end;
end;

// Сортировка -> По возрастанию (Сортируем по полю "Сумма")
procedure TForm1.MenuItemSortAscClick(Sender: TObject);
var
  i, j, k: Integer;
  Temp: string;
begin
  if StringGrid1.RowCount <= 2 then Exit;

  // Простейшая сортировка пузырьком по значению суммы (Колонка 3)
  for i := 1 to StringGrid1.RowCount - 2 do
    for j := i + 1 to StringGrid1.RowCount - 1 do
    begin
      if StrToFloatDef(StringGrid1.Cells[3, i], 0) > StrToFloatDef(StringGrid1.Cells[3, j], 0) then
      begin
        for k := 0 to StringGrid1.ColCount - 1 do
        begin
          Temp := StringGrid1.Cells[k, i];
          StringGrid1.Cells[k, i] := StringGrid1.Cells[k, j];
          StringGrid1.Cells[k, j] := Temp;
        end;
      end;
    end;
  IsModified := True; // Порядок изменился, нужно будет сохранить
end;

// Сортировка -> По убыванию (Сортируем по полю "Сумма")
procedure TForm1.MenuItemSortDescClick(Sender: TObject);
var
  i, j, k: Integer;
  Temp: string;
begin
  if StringGrid1.RowCount <= 2 then Exit;

  for i := 1 to StringGrid1.RowCount - 2 do
    for j := i + 1 to StringGrid1.RowCount - 1 do
    begin
      if StrToFloatDef(StringGrid1.Cells[3, i], 0) < StrToFloatDef(StringGrid1.Cells[3, j], 0) then
      begin
        for k := 0 to StringGrid1.ColCount - 1 do
        begin
          Temp := StringGrid1.Cells[k, i];
          StringGrid1.Cells[k, i] := StringGrid1.Cells[k, j];
          StringGrid1.Cells[k, j] := Temp;
        end;
      end;
    end;
  IsModified := True;
end;

// Действия -> Поиск записи (Поиск по ФИО клиента)
procedure TForm1.MenuItemSearchClick(Sender: TObject);
var
  SearchStr: string;
  i: Integer;
  Found: Boolean;
begin
  SearchStr := InputBox('Поиск договора', 'Введите ФИО клиента (можно частично):', '');
  if Trim(SearchStr) = '' then Exit;

  Found := False;
  for i := 1 to StringGrid1.RowCount - 1 do
  begin
    // Ищем совпадение без учета регистра
    if Pos(LowerCase(SearchStr), LowerCase(StringGrid1.Cells[2, i])) > 0 then
    begin
      StringGrid1.Row := i; // Фокусируемся/подсвечиваем строку таблицы
      Found := True;
      MessageDlg('Запись найдена и выделена в таблице!' + sLineBreak +
                 'Договор №: ' + StringGrid1.Cells[0, i], mtInformation, [mbOK], 0);
      Break;
    end;
  end;

  if not Found then
    ShowMessage('Запись с таким ФИО клиента не найдена.');
end;

end.
