unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  MaskEdit, DateUtils;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnSetAlarm: TButton;
    imgAlarm: TImage;
    lblClock: TLabel;
    edtAlarmTime: TMaskEdit;
    Timer1: TTimer;
    procedure btnSetAlarmClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    AlarmActive: Boolean;
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  AlarmActive := False;
  imgAlarm.Visible := False;
  Timer1.Enabled := True;
  Timer1.Interval := 1000;
  lblClock.Caption := '00:00:00';

  Constraints.MinWidth := Width;
  Constraints.MaxWidth := Width;
  Constraints.MinHeight := Height;
  Constraints.MaxHeight := Height;
end;

procedure TForm1.btnSetAlarmClick(Sender: TObject);
begin
  try
    if not AlarmActive then
    begin
      StrToTime(Trim(edtAlarmTime.Text));
      AlarmActive := True;
      btnSetAlarm.Caption := 'Сбросить';
    end
    else
    begin
      // Логика сброса
      AlarmActive := False;
      imgAlarm.Visible := False;
      btnSetAlarm.Caption := 'Старт';
      edtAlarmTime.Text := ''; // Очистка поля (или '00:00' для шаблона)
    end;
  except
    on E: EConvertError do
      ShowMessage('Ошибка! Введите время ЧЧ:ММ');
  end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  AlarmTime: TDateTime;
  CurrentTimeStr, AlarmTimeStr: string;
begin
  CurrentTimeStr := FormatDateTime('hh:mm:ss', Now);
  lblClock.Caption := CurrentTimeStr;

  if AlarmActive then
  begin
    try
      AlarmTime := StrToTime(Trim(edtAlarmTime.Text));
      CurrentTimeStr := FormatDateTime('hh:mm', Now);
      AlarmTimeStr := FormatDateTime('hh:mm', AlarmTime);

      if CurrentTimeStr = AlarmTimeStr then
      begin
        imgAlarm.Visible := True;
        Beep;
      end;
    except
      AlarmActive := False;
    end;
  end;
end;

end.
