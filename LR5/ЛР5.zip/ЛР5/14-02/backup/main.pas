unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TfMain }

  TfMain = class(TForm)
    Button1: TButton;
    ComboBox1: TComboBox;
    ListBox1: TListBox;
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

end.

